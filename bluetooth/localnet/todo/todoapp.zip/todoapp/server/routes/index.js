
/*
 * GET home page.
 */

exports.index = function(req, res){
  res.render('index', { title: 'Todo App|Express + MongoDB' });
};

exports.index_pc = function(req,res){
	res.render('index_pc',{title:'TodoApp'});
}

exports.index_tab = function(req,res){
	res.render('index_tab',{title:'TodoApp'});
}

exports.index_wcc = function(req,res){
	res.render('index_wcc',{title:'TodoApp'});
}