/*$(function(){
    $.amaran({content:{'message':'1分前です!'}});
});         */

function digitalClock() {
        var now = new Date();
        now.setTime(now.getTime()+540*60*1000);
        var hour = now.getHours();
        var min = now.getMinutes();
        var sec = now.getSeconds();
        if(hour < 10) { hour = "0" + hour; }
        if(min < 10) { min = "0" + min; }
        if(sec < 10) { sec = "0" + sec; }
        //var clock = hour + ':' + min + ':' + sec;
        var clock = hour + ':' + min ;
        document . getElementById( 'digital-clock' ) . innerHTML= clock . toLocaleString();
        /*$("h1").each(function(){
                var minNow = hour * 3600 + min * 60 + sec;
                var numalartTime = $(this).val().toString();
                var alarttime = numalartTime.substr(0,2) * 3600 + numalartTime.substr(2,2) * 60;
                if (alarttime-minNow < 60){
                        $('#alert').append('じかんです');
                }       
        });*/
        window . setTimeout( "digitalClock()", 1000);
/*function alartTask(){
        
        $("h1").each(function(){
                var minNow = hour * 3600 + min * 60 + sec;
                var numalartTime = $(this).val().toString();
                var alarttime = numalartTime.substr(0,2) * 3600 + numalartTime.substr(2,2) * 60;
        if (alarttime-minNow < 60){
                $('#alert').append('じかんです');
                //alert("一分前");
        }
        })
                
//function */
}

window . onload = digitalClock;

