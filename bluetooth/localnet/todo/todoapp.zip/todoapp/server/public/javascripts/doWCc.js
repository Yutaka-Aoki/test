
//jQuery(function($){
$(document).ready(function($){
	"use strict";

	//client side socket.io
	//var socket = io.connect('http://ishuah.com:8080');
	var socket = io.connect('http://10.10.10.2:10080');
	var app = {

		init: function(){
			this.list();
			this.actions();
			this.socketActions();
		},

		persist: function(new_todo){
			
			socket.emit('add', new_todo);
		},

		edit: function(edit_todo){
			
			socket.emit('edit', edit_todo);
		},

		destroy: function(todo_id){
			
			socket.emit('delete', { id:todo_id });
		},

		changeStatus: function(todo_id, todo_status){
			
			socket.emit('changestatus', { id: todo_id, status: todo_status });
		},

		allChangeStatus: function(master_status){
			
			socket.emit('allchangestatus', { status: master_status });
		},

		actions: function(){
			$('#todo-form').submit(function(){
				if(!$('#new-todo').val()){
					return false;
				}
				var new_todo = {
					title: $('#new-todo').val(),
					alarttime: $('#new-time').val(),
					complete: false
				}
				$('#new-todo').val('');
				$('#new-time').val('');
				app.persist(new_todo);

				return false;
			}); 

			//$('button.destroy').live('click', function(e){
			// $(document).on('tap','button.destroy', function(e){
			// //$('button.destroy').click(function(e){
			// 	e.preventDefault();
			// 	app.destroy($(this).attr('data-todoId'));
			// });
			/*
			$('input.toggle').live('click', function(){
			//$('input.toggle').on('click', function(){
				if($(this).prop('checked')){
					app.changeStatus($(this).attr('data-todoId'), 'complete');
				}else{
					app.changeStatus($(this).attr('data-todoId'), 'incomplete');
				}
				
			});

			$('input#toggle-all').live('click', function(){
			//$('input#toggle-all').on('click', function(){
				if ($(this).prop('checked')) {
					app.allChangeStatus('complete');
				}else{
					app.allChangeStatus('incomplete');
				}
			});

			$('ul#todo-list li').live('dblclick', function(){
			//$('ul#todo-list li').on('dblclick', function(){
				$(this).addClass('editing');
				$(this).children('input.edit').focus();
			});

			//$('input.edit').on('focusout',function(){
			$('input.edit').live('focusout',function(){
				if(!$(this).val()){
					app.destroy($(this).attr('data-todoId'));
				}else{
				$('li#'+$(this).attr('data-todoId')+' .view label').html($(this).val());
				var edit_todo = {
					title: $(this).val(),
					id: $(this).attr('data-todoId')
				}

				app.edit(edit_todo);
				$(this).parent().removeClass('editing');

				}
				
			});

			//$('input.edit').on('keypress', function(e){
			/*$('input.edit').live('keypress', function(e){
				 if(e.which == 13) {
				 	if(!$(this).val()){
						app.destroy($(this).attr('data-todoId'));
					}else{
					 	$('li#'+$(this).attr('data-todoId')+' .view label').html($(this).val());
					 	var edit_todo = {
							title: $(this).val(),
							id: $(this).attr('data-todoId')
						}
						app.edit(edit_todo);
	        			$(this).parent().removeClass('editing');

        			}
    			 }
			});*/
		},

		socketActions: function(){
			 socket.on('count', function (data) {
			    $('footer#footer').html(data.count+' users online.');
			  });

			 socket.on('added', function(data){
			 	app.addToList(data);
			 });

			 socket.on('deleted', function(data){
			 	app.destroyOnTodoList(data.id);
			 });

			 socket.on('statuschanged', function(data){
			 	app.markOnTodoList(data.id, data.status);
			 });

			 socket.on('edited', function(data){
			 	$('li#'+data._id+' .view label').html(data.title);
			 	$('li#'+data._id+' input.edit').val(data.title);
			 });

			 socket.on('allstatuschanged', function(data){
			 	app.markAllOnTodoList(data.status);
			 });

			 socket.on('alert',function(){
			 	 $.amaran({
			 	 	content:{
			 	 		'title':'1分前！！',
			 	 		'message':'一分前になった作業があります',
			 	 		'info':'通知',
			 	 		'icon':'fa fa-exclamation fa-5x'

			 	 	},
			 	 	theme:'awesome blue',
			 	 	inEffect:'slideRight'
			 	});
			 });
		},

		list: function(){
			socket.on('all', function(data){
				$('#todo-list').html('');
				for(var i = 0; i< data.length; i++){
					var strTime = data[i].alarttime;
					var strAlarttime = strTime.substr(0,2) + ":" + strTime.substr(2,2);
					if(data[i].complete){
						$('#todo-list').append('<h1 id="'+data[i]._id+'" value="'+data[i].alarttime+'" class=\"completed\"><div class="view"><label>'+data[i].title+ strAlarttime+'</div></h1>');
					}else{
						$('#todo-list').append('<h1 id="'+data[i]._id+'" value="'+data[i].alarttime+'"><div class="view"><label>'+data[i].title + '<span id="margin"></span>' +strAlarttime + '</label></div></h1>');
					}
				}
				//$('#todo-list').listview('refresh');
				app.mainSectionToggle();
			});
			
		},
		addToList: function(new_todo){
			var strTime = new_todo.alarttime;
			var strAlarttime = strTime.substr(0,2) + ":" + strTime.substr(2,2);
			$('#todo-list').append('<h1 id="'+new_todo._id+'" value="'+new_todo.alarttime+'"><div class="view"><label>'+new_todo.title + '<span id="margin"></span>' + strAlarttime +'</label></div></h1>');
			//$('#todo-list').listview('refresh');
			app.mainSectionToggle();
		},
		destroyOnTodoList: function(todo_id){
			$('h1#'+todo_id).remove();
			app.mainSectionToggle();
		},

		markOnTodoList: function(todo_id, todo_status){
			if(todo_status == 'complete'){
				$('li#'+todo_id).addClass('completed');
				$('li#'+todo_id+' div.view input.toggle').attr('checked', true);
			}else{
				$('li#'+todo_id).removeClass('completed');
				$('li#'+todo_id+' div.view input.toggle').attr('checked', false);
			}

			if($('input#toggle-all').prop('checked')){
				$('input#toggle-all').attr('checked', false);
			}
		},

		markAllOnTodoList: function(master_status){
			if(master_status == 'complete'){
				$('ul#todo-list li').addClass('completed');
				$('input.toggle').attr('checked', true);
				$('input#toggle-all').attr('checked', true);
			}else{
				$('ul#todo-list li').removeClass('completed');
				$('input.toggle').attr('checked', false);
				$('input#toggle-all').attr('checked', false);
			}
		},

		mainSectionToggle: function(){
			if(!$('ul#todo-list li').length){
				$('section#main').hide();
				$('footer#footer').hide();
			}else{
				$('section#main').show();
				$('footer#footer').show();
			}
		}
	};

	window.App = app.init();
});


 
